# Handoff: dapp-v2 — Landing + Stake redesign

## Overview

This bundle contains two redesigned screens for `defi-app-v2`:

1. **Landing page** — the public marketing / case-study entry. Two HTML directions are included; the **sparser** direction is the one selected for port.
2. **Stake page** — the in-app staking screen, with a continuously-rolling **Earned-DAPP odometer**, a live rate annotation (DAPP / sec), and a 60-sample sparkline.

The design language is editorial-financial: Fraunces display + JetBrains Mono labels + IBM Plex Sans body, on a warm paper background (Landing) or a deep navy (Stake), with a single ochre accent. It is the same vocabulary already in use elsewhere in the app — these screens are a deeper, more confident application of it.

---

## About the design files

The files under `mocks/` are **design references created in HTML** — prototypes that show intended look and motion. They are not production code and should not be embedded directly.

The files under `port/` are **a first-pass TypeScript/React port** of those designs against the existing `defi-app-v2/frontend` codebase. They use:

- the existing Tailwind tokens defined in `frontend/tailwind.config.js`
- the existing hook contract: `useStakingView()`, `useStakingActions()`, `useAppMode()`, `useSetAppMode()`
- the existing utility helpers: `formatAmount`, `parseAmount`, `getDemoClock`
- the existing UI atoms: `Loader`, `WalletGate`

**These are starting-point ports, not final code.** They are correct to the design but have not been compiled or run against the real codebase. Treat them as you would a PR draft from a designer: lift the structure, the class lists, and the prose verbatim; reconcile imports, type signatures, and behaviour against whatever the codebase looks like today.

## Fidelity

**High-fidelity.** Exact colors, type scale, line lengths, spacing, hover states, and motion are specified in the HTML mocks. The ported TSX matches them pixel-for-pixel against the existing Tailwind tokens.

---

## Files in this bundle

```
design_handoff_dapp_v2/
├── README.md                              ← you are here
├── mocks/
│   ├── Landing-front-matter.html          ← Landing direction A (denser, masthead, drop cap)
│   ├── Landing-sparser.html               ← Landing direction B (selected)
│   └── Stake.html                         ← Stake page
└── port/
    ├── pages/
    │   ├── Landing.tsx                    ← drop-in for frontend/src/pages/Landing.tsx
    │   └── Stake.tsx                      ← drop-in for frontend/src/pages/Stake.tsx
    └── components/
        ├── Odometer.tsx                   ← new component
        └── Sparkline.tsx                  ← new component
```

---

## Screens

### 1. Landing (`pages/Landing.tsx`)

**Purpose.** Convert a cold visitor into a one-click demo launch. Tell the case-study story briefly along the way.

**Layout (single column, 1080px max, generous top margin).**
- **Hero** — `pt-40 pb-44`, max-width 880px. Kicker → Fraunces headline ≈ 108px clamp → 24px sub → CTA row. The headline includes one italic ochre phrase (`legible`).
- **Three chapters** — `grid-cols-3`, `gap-x-16 gap-y-12`. Kicker → 26px Fraunces sub-headline → 16px body. No drop cap. No `§` numbering.
- **By the numbers** — `grid-cols-4` with a single hairline rule across the top. Each cell is a `<Stat>` with hover-reveal footnote.
- **Footer CTA** — left-aligned, 880px max, big italic-ochre highlight, single primary button.

**Stat cell hover behaviour.**
- Ochre baseline (`bg-ochre`) scales from `scale-x-0` → `scale-x-100`, 360ms `cubic-bezier(.2,.8,.2,1)`.
- The "v1" number fades from `text-ink-300` → `text-ink-100`; a `1.5px` strike line draws across it (`scale-x-0` → `scale-x-100`, same easing).
- The connector arrow `→` widens from 22px to 34px and deepens to `text-ochre-deep`.
- The "v2" number scales 1 → 1.02 from `origin-left`.
- A mono footnote (11px, max-width 28ch) reveals via `max-h-0` → `max-h-[90px]` + `opacity` + `mt-5` transition.

**Preserved handler.**
```ts
const setMode = useSetAppMode();
const navigate = useNavigate();
const launchDemo = () => { setMode("demo"); navigate("/app"); };
```
Both CTAs wire to `launchDemo`. The secondary link points at `/case-study`.

**Note on chrome.** The wordmark + nav links visible in the HTML mock live in `NarrativeLayout`, not in `Landing.tsx`. The port leaves them out.

---

### 2. Stake (`pages/Stake.tsx`)

**Purpose.** Let the user stake mDAI, see DAPP rewards accrue continuously, and unstake / claim / exit.

**Layout.**
- **Page header** — kicker, Fraunces 56px (clamp) headline with italic ochre `DAPP`, 18px sub. In demo mode, the sub includes a mono footnote with the chain-clock multiplier.
- **Stat row** — `grid md:grid-cols-[1fr_1fr_1.8fr_1fr]`, separated by 1px `border-navy-rule`. Cells: Wallet mDAI, Staked (emphasized), **Earned DAPP** (centerpiece), Wallet DAPP.
- **Amount input** — full-width 56px-tall mono input, bottom-rule that turns ochre on focus, `Max (balance)` button on the right.
- **Helper line** — mono 12px, switches between three copy variants based on `actions.pending`, `view.staked`, `view.earned`.
- **Action row** — Stake (primary), Unstake amount (secondary), Claim rewards (ghost), Exit everything (ghost, hover terracotta).
- **Pending meter** — when `actions.pending` is truthy, a thin ochre sweep animates across a 56px rule with `actions.pending · waiting for simulated block`.

**Earned-DAPP cell (the moment).**
- Header row: `Earned DAPP` label on the left; on the right, one of three small mono badges — `● Accruing` (ochre pulse-soft dot) when staked and in demo mode, `—` when zero, `Settled` otherwise.
- Body: a thin vertical gradient gutter (`from-transparent via-ochre-deep to-ochre`, only when accruing) + `<Odometer value={earnedNum} decimals={6} slotPx={44} idle={!isAccruing} />` + `DAPP` ticker label.
- Below: `rate · +x.xxxxxx DAPP / sec` (mono, ochre value) and a 60-sample `<Sparkline>` of recent `earned` values.

**Hook contract preserved verbatim.**
```ts
const view    = useStakingView();
const actions = useStakingActions();
```
All disabled / pending predicates from the original `Stake.tsx` are kept unchanged.

**Number conversion.** `view.earned` is a `bigint` (18 decimals). It is converted to a JS `Number` at the display boundary via `Number(view.earned) / 1e18`. This is safe — display-sized DAPP earnings are well inside `Number.MAX_SAFE_INTEGER`. **All on-chain arithmetic must remain in bigint.**

**Rate sampling.** The DAPP/sec rate is sampled in a `useEffect` keyed on `earnedNum`. It computes `(earnedNum - lastEarned) / dt` and smooths exponentially (`prev * 0.7 + r * 0.3`). The sparkline buffer is capped at 60 samples.

---

## New components

### `components/Odometer.tsx`

A rolling-digit display. Integer part is plain text; fractional digits are clipped slot windows over a vertical 0–9 strip. For each slot `p` (1 = tenths):

```
wheelValue = (value × 10^p) mod 10
translateY = -wheelValue × slotPx
```

The fractional component of `wheelValue` drives continuous translateY, so the rightmost digit appears to glide and carries propagate up naturally.

**Props.**
- `value: number` — converted from bigint at the call site.
- `decimals?: number` (default 6) — number of rolling slots.
- `slotPx?: number` (default 44) — slot height in px. **Must match the rendered font-size** for the clip to be exact.
- `idle?: boolean` — render dim placeholder zeros, no motion.
- `rate?: number` — optional inter-update interpolation rate.

### `components/Sparkline.tsx`

A thin ochre line of the last N samples. No tooltip, no axes, no legend. Dot at the head marks the latest value.

**Props.**
- `samples: number[]`
- `width?: number` (default 160)
- `height?: number` (default 28)

---

## Design tokens (all already in `tailwind.config.js`)

**Colors used.** `paper`, `paper-rule`, `ink-100`, `ink-300`, `ink-500`, `ink-700`, `ink-900`, `navy-bg`, `navy-rule`, `ochre`, `ochre-soft`, `ochre-deep`, `terracotta`.

**Typography.**
- `font-display` — Fraunces, used for headlines (medium 500), occasional italics.
- `font-mono` — JetBrains Mono, used for kickers, labels, footnotes, numeric input.
- Body — IBM Plex Sans (default sans), 16px.

**Type scale used.**
- Hero headline: `clamp(56px, 7.6vw, 108px)` / leading 0.98 / tracking -0.028em.
- Footer-CTA headline: `clamp(40px, 5.6vw, 84px)` / leading 1 / tracking -0.024em.
- Section sub-headlines: 26px / leading 1.2 / tracking -0.012em.
- Stat "v2": 48px Fraunces medium, tabular-nums.
- Earned odometer: 44px JetBrains Mono medium.
- Kickers: 11px mono, uppercase, tracking 0.16em.

**Easing.** All interaction transitions: `cubic-bezier(.2,.8,.2,1)` at 320–360ms. Motion is firm and quick — never bouncy.

---

## Implementation checklist

1. **Drop the new components in.** `port/components/Odometer.tsx` and `port/components/Sparkline.tsx` → `frontend/src/components/`.
2. **Replace `Landing.tsx`.** Reconcile the import paths and the `useSetAppMode` + `useNavigate` signatures against the actual hook exports. Verify the `kicker`, `link`, `paper-bg`, `btn-primary`, `btn-secondary`, `btn-ghost`, `animate-rise-in`, `animate-fade-in`, `animate-pulse-soft` utility classes exist in the current Tailwind config / global stylesheet; add the few that don't.
3. **Replace `Stake.tsx`.** Verify the `useStakingView` / `useStakingActions` return-shape matches what the port expects: `view.staked`, `view.earned`, `view.daiBalance`, `view.dappBalance`, `view.allowance` (bigint); `view.isLoading` (boolean); `actions.pending` (string | null — one of `"Approve" | "Stake" | "Unstake" | "Claim" | "Exit"`); `actions.approve / stake / unstake / claim / exit`.
4. **Add the `meterSweep` keyframe** to `tailwind.config.js` if it isn't already present:
   ```js
   keyframes: {
     meterSweep: { '0%': { transform: 'translateX(0)' }, '100%': { transform: 'translateX(380%)' } },
   }
   ```
5. **Smoke-test the demo flow.** Land on `/`, click Launch demo, stake 100 mDAI, watch the odometer roll. The rate annotation should populate within ~1–2 seconds.
6. **Smoke-test sepolia.** Verify the `WalletGate` early-return still fires for unconnected wallets, and that `needsApproval` correctly toggles the Stake button label.

---

## Assets

No new image, icon, or font assets are required. Fonts are already loaded by `index.html`. There are no inline SVGs other than the Sparkline.

## Notes

- **Don't lift the HTML directly.** The HTML mocks use plain CSS variables and standalone class names; the port translates those to Tailwind tokens. If you need to look something up, the HTML is canonical for visual intent and the TSX is canonical for code structure.
- **Two Landing directions are included.** `Landing-front-matter.html` is the denser, masthead-led direction (rejected). `Landing-sparser.html` is the selected one and matches `port/pages/Landing.tsx`. The denser file is retained for reference only.
